module.exports=function(req, res) {
	res.send('Welcome..!! Now  you are now authenticated !');
};