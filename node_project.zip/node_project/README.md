# Node-MySQL-Signup-Login-RESTful-API

### This repo is an example of Login-SignUP  API with NODE.js AND MYSQL and JWT(JSON Web Token) Authentication. 
## Setting up Project 
Open Terminal

 `git clone  https://github.com/akhilpy/Node-MySQL-JWT-Signup-Login-API.git`

 
 ` cd YourProjectFolderName`
 
` npm install`

Open MySQL Client Application (phpmyadmin/sqlManager)
Create Database and Import `users.sql` file.

Then Back to terminal and run following command 

`node server.js`


  
